import axios from "axios";
import {
  CART_ADD_PAYMENT,
  CART_ADD_SHIPPING,
  CART_ITEM_ADD,
  CART_ITEM_ERROR,
  CART_ITEM_REMOVE,
} from "../constants/cartConstant";
export const addToCart = (id, qty) => async (dispatch, getState) => {
  try {
    const { data } = await axios.get(`/api/products/${id}`);
    if (data.countInStock >= qty) {
      const cartItem = {
        product: data._id,
        name: data.name,
        price: data.price,
        image: data.image,
        countInStock: data.countInStock,
        qty: Number(qty),
      };
      dispatch({ type: CART_ITEM_ADD, payload: cartItem });
      let { cartItems } = getState().cart;
      localStorage.setItem("cartItems", JSON.stringify(cartItems));
    } else {
      throw new Error("Invlaid Quantity");
    }
  } catch (error) {
    const errorMessage = error.response
      ? error.response.data.message
      : error.message;
    dispatch({ type: CART_ITEM_ERROR, payload: errorMessage });
  }
};

export const removeFromCart = (id) => (dispatch, getState) => {
  dispatch({ type: CART_ITEM_REMOVE, payload: id });
  let { cartItems } = getState().cart;
  localStorage.setItem("cartItems", JSON.stringify(cartItems));
};

export const addShippingAddress = (shipingAddress) => (dispatch, getState) => {
  dispatch({ type: CART_ADD_SHIPPING, payload: shipingAddress });
  let { shippingAddress } = getState().cart;
  localStorage.setItem("shippingAddress", JSON.stringify(shippingAddress));
};

export const addPaymentType = (payment) => (dispatch, getState) => {
  dispatch({ type: CART_ADD_PAYMENT, payload: payment });
  let { paymentType } = getState().cart;
  localStorage.setItem("paymentType", JSON.stringify(paymentType));
};
