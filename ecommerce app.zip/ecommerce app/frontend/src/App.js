import React from "react";
import { Container } from "react-bootstrap";
import { Routes, Route } from "react-router-dom";
import Footer from "./components/Footer";
import Header from "./components/Header";
import CartScreen from "./screens/CartScreen";
import HomeScreen from "./screens/HomeScreen";
import LoginScreen from "./screens/LoginScreen";
import PaymentScreen from "./screens/PaymentScreen";
import PlaceOrderScreen from "./screens/PlaceOrderScreen";
import ProductScreen from "./screens/ProductScreen";
import RegisterScreen from "./screens/RegisterScreen";
import ShippingScreen from "./screens/ShippingScreen";
import ProfileScreen from "./screens/ProfileScreen";
import OrderScreen from "./screens/OrderScreen";
import DashboardScreen from "./screens/admin/DashboardScreen";
import RequireAuth from "./components/RequireAuth";
import AdminProductScreen from "./screens/admin/AdminProductScreen";
import AdminOrdersScreen from "./screens/admin/AdminOrdersScreen";
import AdminUsersScreen from "./screens/admin/AdminUsersScreen";
import AdminProductEditScreen from "./screens/admin/AdminProductEditScreen";
function App() {
  return (
    <>
      <Header />
      <main className="main">
        <Container className="py-2">
          <Routes>
            <Route path="/" element={<HomeScreen />} />
            <Route path="/product/:id" element={<ProductScreen />} />
            <Route path="/cart" element={<CartScreen />} />
            <Route path="/cart/:id" element={<CartScreen />} />
            <Route path="/login" element={<LoginScreen />} />
            <Route path="/register" element={<RegisterScreen />} />
            <Route path="/shipping" element={<ShippingScreen />} />
            <Route path="/payment" element={<PaymentScreen />} />
            <Route path="/placeorder" element={<PlaceOrderScreen />} />
            <Route path="/profile" element={<ProfileScreen />} />
            <Route path="/order/:id" element={<OrderScreen />} />
          </Routes>
        </Container>
        <Routes>
          <Route
            path="/admin"
            element={
              <RequireAuth isAdmin>
                <DashboardScreen />
              </RequireAuth>
            }
          />
          <Route
            path="/admin/products"
            element={
              <RequireAuth isAdmin>
                <AdminProductScreen />
              </RequireAuth>
            }
          />
          <Route
            path="/admin/products/:id/edit"
            element={
              <RequireAuth isAdmin>
                <AdminProductEditScreen />
              </RequireAuth>
            }
          />
          <Route
            path="/admin/orders"
            element={
              <RequireAuth isAdmin>
                <AdminOrdersScreen />
              </RequireAuth>
            }
          />
          <Route
            path="/admin/users"
            element={
              <RequireAuth isAdmin>
                <AdminUsersScreen />
              </RequireAuth>
            }
          />
        </Routes>
      </main>
      <Footer />
    </>
  );
}

export default App;
