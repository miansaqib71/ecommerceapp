import {
  CART_ADD_PAYMENT,
  CART_ADD_SHIPPING,
  CART_EMPTY,
  CART_ITEM_ADD,
  CART_ITEM_ERROR,
  CART_ITEM_REMOVE,
} from "../constants/cartConstant";

export const cartReducer = (state = { cartItems: [] }, action) => {
  switch (action.type) {
    case CART_ITEM_ADD:
      const cartItem = action.payload;
      const itemExist = state.cartItems.filter(
        (item) => item.product === cartItem.product
      );
      if (itemExist.length > 0) {
        return {
          ...state,
          cartItems: state.cartItems.map((item) =>
            item.product === cartItem.product ? cartItem : item
          ),
          error: null,
        };
      } else {
        return {
          ...state,
          cartItems: [...state.cartItems, cartItem],
          error: null,
        };
      }
    case CART_ITEM_REMOVE:
      const productId = action.payload;
      return {
        ...state,
        cartItems: state.cartItems.filter((item) => item.product !== productId),
        error: null,
      };
    case CART_ITEM_ERROR:
      return {
        ...state,
        error: action.payload,
      };
    case CART_ADD_SHIPPING:
      return {
        ...state,
        shippingAddress: action.payload,
      };
    case CART_ADD_PAYMENT:
      return {
        ...state,
        paymentType: action.payload,
      };
    case CART_EMPTY:
      return { cartItems: [] };
    default:
      return state;
  }
};
