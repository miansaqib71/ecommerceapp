import { faShoppingCart, faTrash } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import React from "react";
import { useEffect } from "react";
import {
  Row,
  Col,
  ListGroup,
  ListGroupItem,
  Image,
  Form,
  Button,
} from "react-bootstrap";
import { useDispatch, useSelector } from "react-redux";
import { LinkContainer } from "react-router-bootstrap";
import {
  Link,
  useParams,
  useSearchParams,
  useNavigate,
} from "react-router-dom";
import { addToCart, removeFromCart } from "../actions/cartActions";
import Message from "../components/Message";

const CartScreen = () => {
  const { id } = useParams();
  const [searchParams] = useSearchParams();
  const qty = searchParams.get("qty") ? searchParams.get("qty") : 1;
  const { cartItems, error } = useSelector((state) => state.cart);
  const navigate = useNavigate();
  console.log(cartItems);
  const dispatch = useDispatch();

  useEffect(() => {
    if (id) {
      dispatch(addToCart(id, qty));
    }
  }, [dispatch, id, qty]);

  const removeHandler = (id) => {
    dispatch(removeFromCart(id));
  };

  const qtyChangeHandler = (id, qty) => {
    dispatch(addToCart(id, qty));
  };

  const proceedToCheckout = () => {
    navigate("/login?redirect=/shipping");
  };

  const emptyCart = () => {
    return (
      <Row className="justify-content-md-center" style={{ paddingTop: "30vh" }}>
        <Col md={4} className="text-center">
          <FontAwesomeIcon icon={faShoppingCart} size="4x" />
          <h3>Shopping cart is empty</h3>
          <LinkContainer to="/">
            <Button>Shop Now</Button>
          </LinkContainer>
        </Col>
      </Row>
    );
  };

  return (
    <>
      {cartItems.length > 0 ? (
        <>
          {" "}
          <Row>
            <Col className="py-3">
              <h3>Shopping Cart</h3>
            </Col>
          </Row>
          <Row>
            <Col md={8}>
              {error && <Message>{error}</Message>}
              <ListGroup variant="flush">
                <ListGroupItem>
                  <Row>
                    <Col lg={1}>Image</Col>
                    <Col lg={3}>Name</Col>
                    <Col lg={2}>Price</Col>
                    <Col lg={2}>Quantity</Col>
                    <Col lg={2}>Total</Col>
                    <Col lg={2}></Col>
                  </Row>
                </ListGroupItem>

                {cartItems.map((cartItem) => (
                  <ListGroupItem key={cartItem.product}>
                    <Row>
                      <Col lg={1}>
                        <Image
                          src={cartItem.image}
                          alt={cartItem.name}
                          fluid
                          width={65}
                        />
                      </Col>
                      <Col lg={3}>
                        <Link to={`/product/${cartItem.product}`}>
                          {cartItem.name}
                        </Link>
                      </Col>
                      <Col lg={2}>Rs {cartItem.price}/-</Col>
                      <Col lg={2}>
                        <Form.Select
                          disabled={cartItem.countInStock === 0}
                          value={cartItem.qty}
                          onChange={(e) =>
                            qtyChangeHandler(cartItem.product, e.target.value)
                          }
                        >
                          {[...Array(cartItem.countInStock).keys()].map(
                            (value) =>
                              value < 5 && (
                                <option key={value} value={value + 1}>
                                  {value + 1}
                                </option>
                              )
                          )}
                        </Form.Select>
                      </Col>
                      <Col lg={2}>Rs = {cartItem.price * cartItem.qty} /-</Col>
                      <Col lg={2}>
                        <Button
                          className="btn-sm"
                          variant="danger"
                          onClick={() => removeHandler(cartItem.product)}
                        >
                          <FontAwesomeIcon icon={faTrash} />
                        </Button>
                      </Col>
                    </Row>
                  </ListGroupItem>
                ))}
              </ListGroup>
            </Col>
            <Col md={4}>
              <ListGroup>
                <ListGroupItem>
                  <Row>
                    <Col>
                      <h3>
                        Subtotal(
                        {cartItems.reduce(
                          (pre, item) => (pre = item.qty + pre),
                          0
                        )}
                        )
                      </h3>
                    </Col>
                  </Row>
                </ListGroupItem>
                <ListGroupItem>
                  <Row>
                    <Col>
                      <h3>Total</h3>
                    </Col>
                    <Col>
                      <h3>
                        Rs{" "}
                        {cartItems.reduce(
                          (pre, item) => (pre = item.qty * item.price + pre),
                          0
                        )}
                        /-
                      </h3>
                    </Col>
                  </Row>
                </ListGroupItem>
                <ListGroupItem>
                  <Row>
                    <Col className="d-grid">
                      <Button onClick={proceedToCheckout}>
                        Proceed To Checkout
                      </Button>
                    </Col>
                  </Row>
                </ListGroupItem>
              </ListGroup>
            </Col>
          </Row>
        </>
      ) : (
        emptyCart()
      )}
    </>
  );
};

export default CartScreen;
