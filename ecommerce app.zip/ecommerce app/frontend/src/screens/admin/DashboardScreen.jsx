import React from "react";
import { Card, Col, Container, Row } from "react-bootstrap";
import { LinkContainer } from "react-router-bootstrap";
import SideMenu from "../../components/SideMenu";

const DashboardScreen = () => {
  return (
    <>
      <SideMenu />
      <Container fluid className="pt-3">
        <Row>
          <Col md={4}>
            <Card className="bg-light">
              <LinkContainer to="/admin/products">
                <Card.Body>
                  <Card.Title>Products</Card.Title>
                  <Card.Text className="text-center display-4">15</Card.Text>
                </Card.Body>
              </LinkContainer>
            </Card>
          </Col>
          <Col md={4}>
            <Card className="bg-light">
              <LinkContainer to="/admin/orders">
                <Card.Body>
                  <Card.Title>Orders</Card.Title>
                  <Card.Text className="text-center display-4">10</Card.Text>
                </Card.Body>
              </LinkContainer>
            </Card>
          </Col>
          <Col md={4}>
            <Card className="bg-light">
              <LinkContainer to="/admin/users">
                <Card.Body>
                  <Card.Title>Users</Card.Title>
                  <Card.Text className="text-center display-4">6</Card.Text>
                </Card.Body>
              </LinkContainer>
            </Card>
          </Col>
        </Row>
      </Container>
    </>
  );
};

export default DashboardScreen;
