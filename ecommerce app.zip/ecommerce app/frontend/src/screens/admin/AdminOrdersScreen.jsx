import React from "react";
import SideMenu from "../../components/SideMenu";

const AdminOrdersScreen = () => {
  return <SideMenu />;
};

export default AdminOrdersScreen;
