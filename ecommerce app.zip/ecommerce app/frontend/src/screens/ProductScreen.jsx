import React, { useEffect } from "react";
import {
  Button,
  Row,
  Col,
  Image,
  ListGroup,
  Badge,
  Form,
} from "react-bootstrap";
import Loader from "../components/Loader";
import Message from "../components/Message";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faArrowLeft } from "@fortawesome/free-solid-svg-icons";
import { useNavigate, useParams } from "react-router-dom";
import Rating from "../components/Rating";
import { useDispatch, useSelector } from "react-redux";
import { getProductDetail } from "../actions/productActions";
import { useState } from "react";

const ProductScreen = () => {
  const { id } = useParams();
  const [qty, setQty] = useState(1);
  const navigator = useNavigate();
  const backHandler = () => {
    navigator(-1);
  };

  const { loading, product, error } = useSelector(
    (state) => state.productDetail
  );

  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(getProductDetail(id));
  }, [dispatch, id]);

  const addToCartHandler = () => {
    navigator(`/cart/${id}?qty=${qty}`);
  };
  return (
    <>
      <Button onClick={backHandler}>
        <FontAwesomeIcon icon={faArrowLeft} /> Back
      </Button>
      {loading ? (
        <Loader />
      ) : error ? (
        <Message>{error}</Message>
      ) : (
        <Row className="py-2">
          {product && (
            <>
              <Col md={5}>
                <Image src={product.image} alt={product.name} fluid />
              </Col>
              <Col md={4}>
                <ListGroup variant="flush">
                  <ListGroup.Item as="h3">{product.name}</ListGroup.Item>
                  <ListGroup.Item>
                    Category :{" "}
                    <span className="text-dark fw-bold">
                      {product.category}
                    </span>
                  </ListGroup.Item>
                  <ListGroup.Item>
                    Fabric :{" "}
                    <span className="text-dark fw-bold">{product.fabric}</span>
                  </ListGroup.Item>
                  <ListGroup.Item>
                    Color :{" "}
                    <span className="text-uppercase fw-bold ">
                      {product.color}
                    </span>
                  </ListGroup.Item>
                  <ListGroup.Item>
                    <Rating
                      rating={product.rating}
                      text={`from ${product.numReviews} users`}
                    />
                  </ListGroup.Item>
                  <ListGroup.Item>{product.description}</ListGroup.Item>
                </ListGroup>
              </Col>
              <Col md={3}>
                <ListGroup>
                  <ListGroup.Item>
                    <Row>
                      <Col>Price</Col>
                      <Col>Rs {product.price}/-</Col>
                    </Row>
                  </ListGroup.Item>
                  <ListGroup.Item>
                    <Row>
                      <Col>Stock</Col>
                      <Col>
                        {product.countInStock > 0 ? (
                          <Badge bg="success">Available</Badge>
                        ) : (
                          <Badge bg="danger">Out of Stock</Badge>
                        )}
                      </Col>
                    </Row>
                  </ListGroup.Item>
                  <ListGroup.Item>
                    <Row>
                      <Col>Quantity</Col>
                      <Col>
                        <Form.Select
                          disabled={product.countInStock === 0}
                          value={qty}
                          onChange={(e) => setQty(e.target.value)}
                        >
                          {[...Array(product.countInStock).keys()].map(
                            (value) =>
                              value < 5 && (
                                <option key={value} value={value + 1}>
                                  {value + 1}
                                </option>
                              )
                          )}
                        </Form.Select>
                      </Col>
                    </Row>
                  </ListGroup.Item>
                  <ListGroup.Item>
                    <Row>
                      <Col className="d-grid">
                        <Button
                          disabled={product.countInStock === 0}
                          onClick={addToCartHandler}
                        >
                          Add to Cart
                        </Button>
                      </Col>
                    </Row>
                  </ListGroup.Item>
                </ListGroup>
              </Col>
            </>
          )}
        </Row>
      )}
    </>
  );
};

export default ProductScreen;
