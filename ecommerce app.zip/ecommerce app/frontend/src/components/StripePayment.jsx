import {
  CardCvcElement,
  CardExpiryElement,
  CardNumberElement,
  useElements,
  useStripe,
} from "@stripe/react-stripe-js";
import React, { useState } from "react";
import { Button, Form } from "react-bootstrap";
import { useDispatch, useSelector } from "react-redux";
import { payOrder, payOrderReset } from "../actions/orderActions";
import Loader from "./Loader";
import Message from "./Message";

const StripePayment = () => {
  const stripe = useStripe();
  const elements = useElements();
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  const orderDetail = useSelector((state) => state.orderDetail);
  const { order } = orderDetail;

  const orderPay = useSelector((state) => state.orderPay);
  const { loading: payLoading, error: payError } = orderPay;

  const dispatch = useDispatch();

  const handlePayment = async (event) => {
    setError(null);

    event.preventDefault();
    if (elements == null) {
      return;
    }
    setLoading(true);
    try {
      const { error, paymentMethod } = await stripe.createPaymentMethod({
        type: "card",
        card: elements.getElement(CardNumberElement),
      });
      if (error) {
        setLoading(false);
        setError(error.message);
        return;
      }
      const { id, card } = paymentMethod;
      dispatch(
        payOrder(order._id, { id, brand: card.brand, last4: card.last4 })
      );
      setLoading(false);
      dispatch(payOrderReset());
    } catch (error) {
      setLoading(false);
      setError(error.message);
    }
  };
  return (
    <>
      {(loading || payLoading) && <Loader />}
      {error && <Message>{error}</Message>}
      {payError && <Message>{payError}</Message>}
      <form onSubmit={handlePayment}>
        <Form.Group className="mb-2">
          <Form.Label>Card Number</Form.Label>
          <CardNumberElement className="form-control" />
        </Form.Group>
        <Form.Group className="mb-2">
          <Form.Label>CVC Number</Form.Label>
          <CardCvcElement className="form-control" />
        </Form.Group>
        <Form.Group className="mb-3">
          <Form.Label>Expiry Date</Form.Label>
          <CardExpiryElement className="form-control" />
        </Form.Group>
        <div className="d-grid">
          <Button type="submit" variant="primary">
            Pay
          </Button>
        </div>
      </form>
    </>
  );
};

export default StripePayment;
