import React from "react";

const Footer = () => {
  return (
    <footer className="py-4 bg-primary text-center text-light">
      All Rights Reserved &copy; {new Date().getFullYear()}
    </footer>
  );
};

export default Footer;
