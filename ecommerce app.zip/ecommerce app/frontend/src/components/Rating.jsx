import React from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faStar as farStar } from "@fortawesome/free-regular-svg-icons";
import {
  faStar as fasStar,
  faStarHalfAlt,
} from "@fortawesome/free-solid-svg-icons";

const Rating = ({ rating, text, variant = "" }) => {
  const totalRating = [1, 2, 3, 4, 5];
  return (
    <>
      {totalRating.map((value) =>
        value <= rating ? (
          <FontAwesomeIcon key={value} icon={fasStar} color={variant} />
        ) : value - 0.5 === rating ? (
          <FontAwesomeIcon key={value} icon={faStarHalfAlt} color={variant} />
        ) : (
          <FontAwesomeIcon key={value} icon={farStar} color={variant} />
        )
      )}{" "}
      {text}
    </>
  );
};

export default Rating;
