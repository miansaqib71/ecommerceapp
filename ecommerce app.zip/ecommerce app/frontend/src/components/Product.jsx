import React from "react";
import { Card } from "react-bootstrap";
import { Link } from "react-router-dom";
import Rating from "./Rating";
const Product = ({ product }) => {
  return (
    <div className="product-card py-2">
      <Link to={`/product/${product._id}`}>
        <Card>
          <Card.Img variant="top" src={product.image} alt={product.name} />
          <Card.Body>
            <Card.Title>{product.name}</Card.Title>
            <Card.Text>
              <Rating
                rating={product.rating}
                text={`from ${product.numReviews} users`}
              />
            </Card.Text>
            <Card.Text as="h5">Rs {product.price}/-</Card.Text>
          </Card.Body>
        </Card>
      </Link>
    </div>
  );
};

export default Product;
