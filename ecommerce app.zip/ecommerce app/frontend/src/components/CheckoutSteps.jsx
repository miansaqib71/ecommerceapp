import React from "react";
import { Col, Row, Nav } from "react-bootstrap";
import { LinkContainer } from "react-router-bootstrap";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faUserAlt,
  faShippingFast,
  faShoppingCart,
  faCreditCard,
} from "@fortawesome/free-solid-svg-icons";

const CheckoutSteps = ({ step1, step2, step3, step4 }) => {
  return (
    <Row className="justify-content-md-center py-3">
      <Col lg={6}>
        <Nav className="justify-content-between" activeKey="/shipping">
          {step1 ? (
            <LinkContainer to="/login?redirect=/shipping">
              <Nav.Link>
                <FontAwesomeIcon icon={faUserAlt} /> Login
              </Nav.Link>
            </LinkContainer>
          ) : (
            <Nav.Item>
              <Nav.Link disabled>
                <FontAwesomeIcon icon={faUserAlt} /> Login
              </Nav.Link>
            </Nav.Item>
          )}
          {step2 ? (
            <LinkContainer to="/login?redirect=/shipping">
              <Nav.Link>
                <FontAwesomeIcon icon={faShippingFast} /> Shipping
              </Nav.Link>
            </LinkContainer>
          ) : (
            <Nav.Item>
              <Nav.Link disabled>
                <FontAwesomeIcon icon={faShippingFast} /> Shipping
              </Nav.Link>
            </Nav.Item>
          )}
          {step3 ? (
            <LinkContainer to="/login?redirect=/shipping">
              <Nav.Link>
                <FontAwesomeIcon icon={faCreditCard} /> Payment
              </Nav.Link>
            </LinkContainer>
          ) : (
            <Nav.Item>
              <Nav.Link disabled>
                <FontAwesomeIcon icon={faCreditCard} /> Payment
              </Nav.Link>
            </Nav.Item>
          )}
          {step4 ? (
            <LinkContainer to="/login?redirect=/shipping">
              <Nav.Link>
                <FontAwesomeIcon icon={faShoppingCart} /> Place Order
              </Nav.Link>
            </LinkContainer>
          ) : (
            <Nav.Item>
              <Nav.Link disabled>
                <FontAwesomeIcon icon={faShoppingCart} /> Place Order
              </Nav.Link>
            </Nav.Item>
          )}
        </Nav>
      </Col>
    </Row>
  );
};

export default CheckoutSteps;
