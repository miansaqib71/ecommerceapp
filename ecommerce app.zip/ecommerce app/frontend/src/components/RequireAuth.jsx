import React from "react";
import { Navigate } from "react-router-dom";
import { useSelector } from "react-redux";
const RequireAuth = ({ children, isAdmin = false }) => {
  const { loading, userInfo } = useSelector((state) => state.userLogin);

  if (!loading && !userInfo) {
    return <Navigate to="/login" />;
  }

  if (isAdmin && userInfo && !userInfo.isAdmin) {
    return <Navigate to="/login?redirect=/admin" />;
  }

  return children;
};

export default RequireAuth;
