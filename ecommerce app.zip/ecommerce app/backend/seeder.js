import dotenv from "dotenv";
import colors from "colors";
import ConnectDb from "./config/db.js";
import User from "./models/user.js";
import Product from "./models/product.js";
import userData from "./data/users.js";
import productData from "./data/products.js";

const SeedData = async () => {
  try {
    await ConnectDb();
    await User.deleteMany();
    await Product.deleteMany();

    const users = await User.insertMany(userData);
    const adminUser = users[0]._id;
    const updatedProducts = productData.map((product) => ({
      ...product,
      user: adminUser,
    }));
    await Product.insertMany(updatedProducts);
    console.log(`Data Imported Successfully`.bgCyan.black);
    process.exit();
  } catch (error) {
    console.error(`Data Imported Failed`.bgRed.white);
    process.exit(1);
  }
};

const DestoryData = async () => {
  try {
    await ConnectDb();
    await User.deleteMany();
    await Product.deleteMany();

    console.log(`Data Deleted Successfully`.bgCyan.black);
    process.exit();
  } catch (error) {
    console.error(`Data Delete Failed`.bgRed.white);
    process.exit(1);
  }
};

dotenv.config();
console.log(process);
if (process.argv[2] === "-d") {
  DestoryData();
} else {
  SeedData();
}
