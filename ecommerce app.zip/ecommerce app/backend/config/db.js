import mongoose from "mongoose";

const ConnectDb = async () => {
  //   mongoose
  //     .connect(
  //       "mongodb+srv://shopify:Qwe123@muzamildev.r7chj.mongodb.net/shopify?retryWrites=true&w=majority"
  //     )
  //     .then((res) => {
  //       console.log(res);
  //     })
  //     .catch((error) => {
  //       console.error("Error :", error.message);
  //     });
  try {
    const db = await mongoose.connect(process.env.MONGO_URI);

    console.log(
      `✅✅✅ Database connected with host : ${db.connection.host}.`.inverse
        .blue
    );
  } catch (error) {
    console.error(
      `❌❌❌ Error connecting database : ${error.message}`.inverse.red
    );
    process.exit(1);
  }
};

export default ConnectDb;
