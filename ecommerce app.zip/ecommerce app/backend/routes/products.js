import express from "express";
import {
  createProduct,
  editProduct,
  getProductById,
  getProducts,
} from "../controllers/products.js";
import { adminHandler, authHandler } from "../middlewares/authHandler.js";

const router = express.Router();

router.get("/", getProducts);

router.get("/:id", getProductById);

router.post("/", authHandler, adminHandler, createProduct);

router.put("/:id", authHandler, adminHandler, editProduct);

export default router;
