import express from "express";
import {
  createOrder,
  getMyOrders,
  getOrderById,
  payOrders,
} from "../controllers/orders.js";
import { authHandler } from "../middlewares/authHandler.js";

const router = express.Router();

router.post("/", authHandler, createOrder);

router.get("/my", authHandler, getMyOrders);

router.get("/:id", authHandler, getOrderById);

router.post("/:id/pay", authHandler, payOrders);

export default router;
