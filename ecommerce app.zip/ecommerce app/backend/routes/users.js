import express from "express";
import { login, register, userInfo, userUpdate } from "../controllers/users.js";
import { authHandler } from "../middlewares/authHandler.js";

const router = express.Router();

router.post("/login", login);

router.post("/register", register);

router.get("/profile", authHandler, userInfo);

router.post("/profile", authHandler, userUpdate);

export default router;
