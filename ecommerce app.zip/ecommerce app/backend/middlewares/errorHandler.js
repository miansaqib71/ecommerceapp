export const notFoundHandler = (req, res, next) => {
  res.statusCode = 404;
  throw new Error(`Api with ${req.url} not exist.`);
};

export const errorHandler = (error, req, res, next) => {
  const statusCode = res.statusCode === 200 ? 500 : res.statusCode;
  res.statusCode = statusCode;
  res.json({
    message: error.message,
    stack: process.env.NODE_ENV === "development" ? error.stack : null,
  });
};
