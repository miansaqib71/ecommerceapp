import User from "../models/user.js";
import asyncHandler from "express-async-handler";

// @path:   /api/users/login
// @desc:   Login user
// @access: Public
export const login = asyncHandler(async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email });
  if (user && (await user.comparePassword(password))) {
    res.statusCode = 200;
    return res.json({
      _id: user._id,
      name: user.name,
      email: user.email,
      isAdmin: user.isAdmin,
      token: user.generateToken(),
    });
  }
  res.statusCode = 400;
  throw new Error("Invalid username or password");
});

// @path:   /api/users/register
// @desc:   Register user
// @access: Public
export const register = asyncHandler(async (req, res) => {
  const { name, email, password } = req.body;

  const user = new User({
    name,
    email,
    password,
  });

  const createdUser = await user.save();

  res.statusCode = 200;
  return res.json({
    _id: createdUser._id,
    name: createdUser.name,
    email: createdUser.email,
    isAdmin: createdUser.isAdmin,
    token: createdUser.generateToken(),
  });
});

// @path:   /api/users/profile
// @desc:   Get User Profile
// @access: Private
export const userInfo = asyncHandler(async (req, res) => {
  const user = await User.findById(req.user._id);
  if (!user) {
    res.statusCode = 404;
    throw new Error("User not found");
  }
  res.statusCode = 200;
  return res.json({
    _id: user._id,
    name: user.name,
    email: user.email,
    isAdmin: user.isAdmin,
    token: user.generateToken(),
  });
});

// @path:   /api/users/profile
// @desc:   update User Profile
// @access: Private
export const userUpdate = asyncHandler(async (req, res) => {
  const user = await User.findById(req.user._id);
  if (!user) {
    res.statusCode = 404;
    throw new Error("User not found");
  }
  const { name, password } = req.body;

  user.name = name || user.name;
  if (password) {
    user.password = password;
  }

  const updatedUser = await user.save();

  res.statusCode = 200;
  return res.json({
    _id: updatedUser._id,
    name: updatedUser.name,
    email: updatedUser.email,
    isAdmin: updatedUser.isAdmin,
    token: updatedUser.generateToken(),
  });
});
