import Product from "../models/product.js";
import asyncHandler from "express-async-handler";
// @path:   /api/products
// @desc:   Get all products
// @access: Public
export const getProducts = asyncHandler(async (req, res) => {
  const products = await Product.find();
  res.json(products);
});

// @path:   /api/products/:id
// @desc:   Get single product by id
// @access: Public
export const getProductById = asyncHandler(async (req, res) => {
  const { id } = req.params;

  const product = await Product.findById(id);

  if (product) {
    return res.json(product);
  }
  res.statusCode = 404;
  throw new Error("Product not found");
});

// @path:   /api/products
// @desc:   Create Product
// @access: Private/Admin
export const createProduct = asyncHandler(async (req, res) => {
  let product = new Product({
    name: "Sample Product",
    image: "/images/no-image.jpg",
    description: "Sample Description",
    color: "black",
    category: "Boys",
    fabric: "Cotton",
    price: 0,
    countInStock: 0,
    rating: 0,
    numReviews: 0,
    user: req.user._id,
  });
  const createdProduct = await product.save();
  res.statusCode = 201;
  res.json({ _id: createdProduct._id });
});

// @path:   /api/products/:id
// @desc:   Create Product
// @access: Private/Admin
export const editProduct = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const product = await Product.findById(id);

  if (!product) {
    res.statusCode = 404;
    throw new Error("Product not found");
  }

  const {
    name,
    image,
    description,
    color,
    category,
    fabric,
    price,
    countInStock,
  } = req.body;

  product.name = name;
  product.image = image;
  product.description = description;
  product.color = color;
  product.category = category;
  product.fabric = fabric;
  product.price = price;
  product.countInStock = countInStock;

  await product.save();
  res.statusCode = 200;
  res.json({});
});
