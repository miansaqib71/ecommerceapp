import Order from "../models/order.js";
import Product from "../models/product.js";
import asyncHandler from "express-async-handler";
import Stripe from "stripe";
// @path:   /api/orders
// @desc:   create new order
// @access: Private
export const createOrder = asyncHandler(async (req, res) => {
  const {
    orderItems,
    shippingAddress,
    paymentType,
    itemsPrice,
    shippingPrice,
    taxPrice,
    totalPrice,
  } = req.body;

  let order = new Order({
    orderItems,
    shippingAddress,
    paymentType,
    itemsPrice,
    shippingPrice,
    taxPrice,
    totalPrice,
    user: req.user._id,
  });
  const createdOrder = await order.save();
  res.statusCode = 201;
  res.json({ _id: createdOrder._id });
});

// @path:   /api/orders/:id
// @desc:   Get single order by id
// @access: Private
export const getOrderById = asyncHandler(async (req, res) => {
  const { id } = req.params;

  const order = await Order.findById(id).populate("user", "name email");

  if (order) {
    return res.json(order);
  }
  res.statusCode = 404;
  throw new Error("Order not found");
});

// @path:   /api/orders/my
// @desc:   Get My orders
// @access: Private
export const getMyOrders = asyncHandler(async (req, res) => {
  const orders = await Order.find({ user: req.user._id });

  if (orders) {
    return res.json(orders);
  }
  res.statusCode = 404;
  throw new Error("Orders not found");
});
const removeItemFromStock = async (id, qty) => {
  try {
    const product = await Product.findById(id);
    product.countInStock = product.countInStock - qty;
    await product.save();
  } catch (error) {
    throw new Error(error);
  }
};

// @path:   /api/orders/:id/pay
// @desc:   Pay order
// @access: Private
export const payOrders = asyncHandler(async (req, res) => {
  const order = await Order.findById(req.params.id).populate("user", "name");
  const { id, brand, last4 } = req.body;
  if (order) {
    const stripe = new Stripe(
      "sk_test_51IutRpCcy8OEmYvUq77adzYjJTDLe8TJl5UW6eg99TzYWTfIofFKeY4G30I70p7ajKhlAuw8lXfCjgpRDxAyxZUX004L1dEEEP"
    );

    await stripe.paymentIntents.create({
      payment_method: id,
      currency: "PKR",
      amount: order.totalPrice * 100,
      description: `${order._id} has been created by ${order.user.name}.`,
      confirm: true,
      metadata: { id: order._id },
    });
    let today = new Date();
    order.isPaid = true;
    order.paidAt = today;
    order.paymentMethod = {
      id,
      brand,
      last4,
    };
    await order.save();
    order.orderItems.forEach(async (item) => {
      await removeItemFromStock(item.product, item.qty);
    });

    return res.json({ message: "Order is paid" });
  }
  res.statusCode = 404;
  throw new Error("Order not found");
});
